from fabgui import fab

def main():
	fab()
