from setuptools import setup
setup(name='Fab GUI',
      version='1.5.1',
      description='GUI Client for Fabric CA',
      author='Athul',
      author_email='athul7744@outlook.com',
      license='MIT',
      packages=['fabgui'],
      entry_points = {
          'console_scripts': ['fabgui=fabgui.command_line:main'],
          },
      zip_safe=False)
